# EyeCare — Ko'z tekshiruvi (MVP)

AI yordamida 10 soniyada ko'z holatini tekshiradigan mobil-birinchi veb-ilova.
Foydalanuvchi old kamera orqali suratga olinadi, ko'z sohasi aniqlanib,
qizarish va ochiqlik darajasi baholanadi, so'ng qisqa tavsiya va sinovdan
o'tgan davo vositalari taklif qilinadi.

## Oqim

1. **Bosh sahifa** — ikkita asosiy tugma: «Ko'zni AI tekshiruvi» va «Davo vositalari»
2. **Ogohlantirish modali** — xizmat tibbiy qurilma emasligi, shartlarga rozilik
3. **Yo'riqnoma (2 bosqich)** — ko'zoynakni yechish, yuzni yashil ramkaga joylashtirish
4. **Kamera** — old kamera, yashil oval ramka, 3-2-1 hisob bilan surat olish
5. **Tahlil** — MediaPipe Face Landmarker (to'liq brauzerda, rasm serverga yuborilmaydi)
6. **Natija** — shox parda va namlik skorlari, 5 yulduzli umumiy baho, ko'z kesmalari
7. **Ma'lumot sahifasi** — shox parda shikastlanishi haqida + davo vositasi tavsiyasi

## Texnologiyalar

- **Next.js 16** (App Router) + **TypeScript** + **Tailwind CSS v4**
- **@mediapipe/tasks-vision** — Face Landmarker (478 nuqta, iris bilan)
  - wasm va model self-hosted: `npm install` paytida `scripts/setup-assets.mjs`
    (postinstall) wasm'ni paketdan ko'chiradi, modelni yuklab oladi
  - tahlil 100% klient tomonida — maxfiylik uchun rasm qurilmadan chiqmaydi

## Tahlil algoritmi (MVP, evristik)

`src/lib/analysis.ts`:

- Ko'z konturi ichidagi piksellar (iris doirasi chiqarib tashlanadi) bo'yicha
  **qizillik ulushi** `R/(R+G+B)` o'rtachasi olinadi: oq sklera ≈ 0.33,
  qizargan ko'z ≈ 0.42+
- **EAR** (Eye Aspect Ratio) orqali ko'z ochiqligi — charchoq belgisi sifatida
- Umumiy ball: `100 − 0.7·qizarish − 0.3·charchoq`, darajalar:
  ≥75 yaxshi / ≥50 o'rtacha / <50 e'tibor talab

> ⚠️ Bu evristik baho — tibbiy tashxis emas. Kalibrlash koeffitsiyentlari
> `analysis.ts` ichida bitta joyda turibdi.

## Sozlash

Brend nomi, sarlavha va mahsulotlar ro'yxati: `src/config/site.ts`

## Ishga tushirish

```bash
npm install
npm run dev
```

Kamera faqat **HTTPS** yoki `localhost` da ishlaydi. Telefonda sinash uchun
`npm run dev` ni tunnel (masalan, ngrok / cloudflared) orqali oching yoki
deploy qiling (Vercel va h.k.).

## Tuzilma

```
src/
  app/
    page.tsx          # bosh sahifa
    check/page.tsx    # kamera + suratga olish
    result/page.tsx   # tahlil natijasi (skorlar, yulduzlar)
    info/page.tsx     # shox parda haqida + mahsulot CTA
    products/page.tsx # davo vositalari
    terms/page.tsx    # foydalanish shartlari
  components/         # modal oqimi, nav, ikonkalar, illyustratsiyalar
  config/site.ts      # brend va mahsulotlar
  lib/analysis.ts     # MediaPipe + ko'z tahlili
```
